/** @type {import('next').NextConfig} */
const nextConfig = {
    output: 'export',
    basePath: '/static-site-lab',
};

module.exports = nextConfig;
